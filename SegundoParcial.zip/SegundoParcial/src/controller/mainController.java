package controller;


import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import model.*;

public class mainController {

    @FXML
    private ComboBox comboBoxx;

    @FXML
    private TextField txtNombre;

    @FXML
    private Button btnAgregar;

    @FXML
    private Button btnNuevoTipo;

    @FXML
    private Button btnEliminar;

    @FXML
    private Button btnGuardar;

    @FXML
    private TableColumn<Visitante, String> colNombre;

    @FXML
    private TableColumn<Visitante,String> colTipo;


    private ObservableList<Visitante> visitantes;


     @FXML
    private void initialize() {
    

        

    }
    @FXML
    private void agregarVisitante() {
        

        if (txtNombre.equals("")){
        
        }

        if (visitantes.isEmpty()){
            
        }
    }
   


}

