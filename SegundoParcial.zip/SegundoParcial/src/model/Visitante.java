package model;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Visitante {
    
    private SimpleStringProperty nombre;

    private SimpleStringProperty tipo;

    public Visitante(String nombre, String tipo) {
        this.nombre = new SimpleStringProperty(nombre);
        this.tipo = new SimpleStringProperty(tipo);
    }

      public StringProperty nombreProperty() { 
        return nombre; 
    }

    public StringProperty tipoProperty() {
        return tipo;
    }
    public SimpleStringProperty getNombre() { 
        return nombre; 
    }

    @Override
    public String toString() {
        return "El nombre del visitante es: " + nombre + "El tipo de visitante es: " + tipo;
    }
}
