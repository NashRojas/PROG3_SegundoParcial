import java.io.IOException;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class App extends Application {
   
    @Override
    public void start(Stage stage) throws IOException {
     FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/mainview.fxml"));
        Scene scene = new Scene(loader.load());

        stage.setTitle("Registro de Visitantes");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}